# Prosta nierelacyjna baza danych w pliku json

# Uruchomienie
- pobierz, rozpakuj i uruchom `npm install`
- wykonaj polecenie `npm start`
- serwer uruchamia się na http://localhost:3000

# Dostępne endpointy
http://localhost:3000/movies

http://localhost:3000/categories

http://localhost:3000/years

# Korzystam z:
https://github.com/typicode/json-server
